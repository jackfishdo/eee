require("dotenv").config();
const { Telegraf } = require("telegraf");
const mongoose = require("mongoose");
const User = require("./models/User");

const bot = new Telegraf(process.env.BOT_TOKEN);

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.error("MongoDB error:", err));

bot.start(async (ctx) => {
  const username = ctx.from.username.toLowerCase();
  let user = await User.findOne({ username });

  if (!user) {
    user = new User({ username, balance: 0, tapsToday: 0 });
    await user.save();
  }

  ctx.reply("🚀 Welcome to Techno Surge! Use /tap to earn. Use /balance to check your wallet.");
});

bot.command("tap", async (ctx) => {
  const username = ctx.from.username.toLowerCase();
  const user = await User.findOne({ username });

  if (!user || user.tapsToday >= 20) {
    return ctx.reply("You have reached your tap limit for today!");
  }

  user.tapsToday += 1;
  const bonus = user.tapsToday % 10 === 0 ? 0.1 : 0;
  const dailyEarnings = 3.5 + bonus;
  const earned = (user.package || 100) * (dailyEarnings / 100 / 20);
  user.balance += earned;

  await user.save();

  const energyBar = "⚡".repeat(user.tapsToday) + "⚪".repeat(20 - user.tapsToday);
  ctx.reply(`+${earned.toFixed(2)} USDT
Energy: ${energyBar}`);
});

bot.command("balance", async (ctx) => {
  const username = ctx.from.username.toLowerCase();
  const user = await User.findOne({ username });
  ctx.reply(`💰 Your balance is ${user?.balance.toFixed(2) || 0} USDT`);
});

bot.launch();